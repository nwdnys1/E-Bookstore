import { useEffect } from "react";
import { BasicLayout } from "../layouts";
import { checkLogin } from "../services/loginService";

const StasticsPage = () => {
  return (
    <BasicLayout>
      <div>Stastics Page</div>
    </BasicLayout>
  );
};

export default StasticsPage;
